# session.py
user_id = None
user_role = None
user_name = None
